import{ah as a}from"./framework-DgOA0tWV.js";const r=a("v-spacer","div","VSpacer");export{r as V};
