import{ab as a}from"./framework-DXDxJ1VI.js";const r=a("v-spacer","div","VSpacer");export{r as V};
