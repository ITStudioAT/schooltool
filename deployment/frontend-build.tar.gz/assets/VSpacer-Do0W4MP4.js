import{a5 as a}from"./framework-BtkM1k_M.js";const r=a("v-spacer","div","VSpacer");export{r as V};
