import{a5 as a}from"./framework-CKLcBDFa.js";const r=a("v-spacer","div","VSpacer");export{r as V};
