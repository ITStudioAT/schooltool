import{a5 as a}from"./framework-VXS3MknR.js";const r=a("v-spacer","div","VSpacer");export{r as V};
