import{ab as a}from"./framework-CVRgQH9J.js";const r=a("v-spacer","div","VSpacer");export{r as V};
