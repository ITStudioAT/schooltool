const s="/build/assets/pdf.worker.min-yatZIOMy.js";export{s as default};
