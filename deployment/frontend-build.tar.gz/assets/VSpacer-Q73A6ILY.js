import{a5 as a}from"./framework-DUl0suNw.js";const r=a("v-spacer","div","VSpacer");export{r as V};
