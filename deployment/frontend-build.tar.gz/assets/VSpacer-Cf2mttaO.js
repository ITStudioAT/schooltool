import{a5 as a}from"./framework-CwAgWnX4.js";const r=a("v-spacer","div","VSpacer");export{r as V};
