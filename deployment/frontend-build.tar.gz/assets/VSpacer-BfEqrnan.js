import{a5 as a}from"./framework-DpzeiuA5.js";const r=a("v-spacer","div","VSpacer");export{r as V};
