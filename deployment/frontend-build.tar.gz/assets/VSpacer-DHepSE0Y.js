import{S as a}from"./framework-D1Vp-ktZ.js";const r=a("v-spacer","div","VSpacer");export{r as V};
