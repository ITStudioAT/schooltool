import{a8 as a}from"./framework-BM6-Uwpe.js";const r=a("v-spacer","div","VSpacer");export{r as V};
