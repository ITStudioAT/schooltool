const e="Neues Menü";export{e as N};
