import{a8 as a}from"./framework-C53jrnxT.js";const r=a("v-spacer","div","VSpacer");export{r as V};
