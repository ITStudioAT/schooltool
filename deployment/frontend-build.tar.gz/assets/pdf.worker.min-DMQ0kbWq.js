const s="/build/assets/pdf.worker.min-yatZIOMy.mjs";export{s as default};
