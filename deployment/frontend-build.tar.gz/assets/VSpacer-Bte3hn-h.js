import{a8 as a}from"./framework-CJLM5Wqy.js";const r=a("v-spacer","div","VSpacer");export{r as V};
