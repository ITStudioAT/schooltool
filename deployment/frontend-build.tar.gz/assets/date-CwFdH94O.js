function o(n){if(n instanceof Date)return n;if(typeof n=="string"&&/^\d{4}-\d{2}-\d{2}$/.test(n)){const[t,e,r]=n.split("-").map(Number);return new Date(t,e-1,r)}return new Date(n)}export{o as p};
