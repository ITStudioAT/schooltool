import{a5 as a}from"./framework-9LcpdlyG.js";const r=a("v-spacer","div","VSpacer");export{r as V};
