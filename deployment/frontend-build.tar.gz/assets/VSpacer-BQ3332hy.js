import{ab as a}from"./framework-DhYkTt-k.js";const r=a("v-spacer","div","VSpacer");export{r as V};
