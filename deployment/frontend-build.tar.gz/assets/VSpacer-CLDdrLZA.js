import{a8 as a}from"./framework-BJ2tyMpe.js";const r=a("v-spacer","div","VSpacer");export{r as V};
