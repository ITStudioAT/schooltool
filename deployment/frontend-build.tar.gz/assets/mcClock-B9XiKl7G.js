function r(t,a){return Math.max(0,Math.ceil((Date.parse(t)-a)/1e3))}function n(t){return`${Math.floor(t/60)}:${String(t%60).padStart(2,"0")}`}export{n as f,r as m};
