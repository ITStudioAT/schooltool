import{a5 as a}from"./framework-mmHGFqAU.js";const r=a("v-spacer","div","VSpacer");export{r as V};
