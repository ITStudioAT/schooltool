import{a5 as a}from"./framework-D4BvI0FD.js";const r=a("v-spacer","div","VSpacer");export{r as V};
