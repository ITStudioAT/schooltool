import{S as a}from"./framework-CFHgE4V0.js";const r=a("v-spacer","div","VSpacer");export{r as V};
