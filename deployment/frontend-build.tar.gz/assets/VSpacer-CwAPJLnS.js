import{aj as a}from"./framework-DnvwTBA9.js";const r=a("v-spacer","div","VSpacer");export{r as V};
