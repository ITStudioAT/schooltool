import{ab as a}from"./framework-BJhpgO6d.js";const r=a("v-spacer","div","VSpacer");export{r as V};
