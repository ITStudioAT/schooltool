import{S as a}from"./framework-B-VxH2Ms.js";const r=a("v-spacer","div","VSpacer");export{r as V};
