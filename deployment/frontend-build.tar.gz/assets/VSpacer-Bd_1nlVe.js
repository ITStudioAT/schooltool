import{ai as a}from"./framework-B0yJVHFf.js";const r=a("v-spacer","div","VSpacer");export{r as V};
