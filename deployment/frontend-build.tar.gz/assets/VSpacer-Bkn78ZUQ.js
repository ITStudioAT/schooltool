import{a5 as a}from"./framework-D7CP5MuZ.js";const r=a("v-spacer","div","VSpacer");export{r as V};
