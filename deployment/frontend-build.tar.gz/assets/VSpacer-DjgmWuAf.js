import{S as a}from"./framework-CfVrgpLd.js";const r=a("v-spacer","div","VSpacer");export{r as V};
