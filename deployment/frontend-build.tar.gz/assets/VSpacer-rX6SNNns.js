import{a5 as a}from"./framework-D2rI7eIv.js";const r=a("v-spacer","div","VSpacer");export{r as V};
