import{a5 as a}from"./framework-DBkV-7_Y.js";const r=a("v-spacer","div","VSpacer");export{r as V};
